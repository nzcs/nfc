#!/usr/bin/env node
(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "./apps/generator-cli/src/app/app.module.ts":
/*!**************************************************!*\
  !*** ./apps/generator-cli/src/app/app.module.ts ***!
  \**************************************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "tslib");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @nestjs/common */ "@nestjs/common");
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var commander__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! commander */ "commander");
/* harmony import */ var commander__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(commander__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var url__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! url */ "url");
/* harmony import */ var url__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(url__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./constants */ "./apps/generator-cli/src/app/constants/index.ts");
/* harmony import */ var _controllers_version_manager_controller__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./controllers/version-manager.controller */ "./apps/generator-cli/src/app/controllers/version-manager.controller.ts");
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./services */ "./apps/generator-cli/src/app/services/index.ts");
var _a, _b, _c;







let proxyConfig;
const proxyUrl = process.env.HTTPS_PROXY || process.env.HTTP_PROXY;
if (proxyUrl) {
    const proxy = url__WEBPACK_IMPORTED_MODULE_3__["parse"](proxyUrl);
    const proxyAuth = proxy.auth && proxy.auth.split(':');
    proxyConfig = {
        host: proxy.hostname,
        port: parseInt(proxy.port, 10),
        auth: proxyAuth && { username: proxyAuth[0], password: proxyAuth[1] },
        protocol: proxy.protocol.replace(':', '')
    };
}
let AppModule = class AppModule {
    constructor(program, versionManager, passThroughService) {
        this.program = program;
        this.versionManager = versionManager;
        this.passThroughService = passThroughService;
        this.onApplicationBootstrap = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let selectedVersion = this.versionManager.getSelectedVersion();
            if (!selectedVersion) {
                const [{ version }] = yield this.versionManager.search(['latest']).toPromise();
                yield this.versionManager.setSelectedVersion(version);
                selectedVersion = version;
            }
            yield this.versionManager.downloadIfNeeded(selectedVersion);
            yield this.passThroughService.init();
            this.program.parse(process.argv);
        });
    }
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Module"])({
        imports: [_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["HttpModule"].register({ proxy: proxyConfig })],
        controllers: [
            _controllers_version_manager_controller__WEBPACK_IMPORTED_MODULE_5__["VersionManagerController"]
        ],
        providers: [
            _services__WEBPACK_IMPORTED_MODULE_6__["UIService"],
            _services__WEBPACK_IMPORTED_MODULE_6__["ConfigService"],
            _services__WEBPACK_IMPORTED_MODULE_6__["GeneratorService"],
            _services__WEBPACK_IMPORTED_MODULE_6__["PassThroughService"],
            _services__WEBPACK_IMPORTED_MODULE_6__["VersionManagerService"],
            {
                provide: _constants__WEBPACK_IMPORTED_MODULE_4__["COMMANDER_PROGRAM"],
                useValue: new commander__WEBPACK_IMPORTED_MODULE_2__["Command"]('openapi-generator-cli').helpOption(false).usage('<command> [<args>]')
            },
            { provide: _constants__WEBPACK_IMPORTED_MODULE_4__["LOGGER"], useValue: console }
        ]
    }),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_constants__WEBPACK_IMPORTED_MODULE_4__["COMMANDER_PROGRAM"])),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [typeof (_a = typeof commander__WEBPACK_IMPORTED_MODULE_2__["Command"] !== "undefined" && commander__WEBPACK_IMPORTED_MODULE_2__["Command"]) === "function" ? _a : Object, typeof (_b = typeof _services__WEBPACK_IMPORTED_MODULE_6__["VersionManagerService"] !== "undefined" && _services__WEBPACK_IMPORTED_MODULE_6__["VersionManagerService"]) === "function" ? _b : Object, typeof (_c = typeof _services__WEBPACK_IMPORTED_MODULE_6__["PassThroughService"] !== "undefined" && _services__WEBPACK_IMPORTED_MODULE_6__["PassThroughService"]) === "function" ? _c : Object])
], AppModule);



/***/ }),

/***/ "./apps/generator-cli/src/app/constants/index.ts":
/*!*******************************************************!*\
  !*** ./apps/generator-cli/src/app/constants/index.ts ***!
  \*******************************************************/
/*! exports provided: LOGGER, COMMANDER_PROGRAM */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LOGGER", function() { return LOGGER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "COMMANDER_PROGRAM", function() { return COMMANDER_PROGRAM; });
const LOGGER = Symbol('LOGGER');
const COMMANDER_PROGRAM = Symbol('COMMANDER_PROGRAM');


/***/ }),

/***/ "./apps/generator-cli/src/app/controllers/version-manager.controller.ts":
/*!******************************************************************************!*\
  !*** ./apps/generator-cli/src/app/controllers/version-manager.controller.ts ***!
  \******************************************************************************/
/*! exports provided: VersionManagerController */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VersionManagerController", function() { return VersionManagerController; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "tslib");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @nestjs/common */ "@nestjs/common");
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../constants */ "./apps/generator-cli/src/app/constants/index.ts");
/* harmony import */ var commander__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! commander */ "commander");
/* harmony import */ var commander__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(commander__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! chalk */ "chalk");
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(chalk__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _services__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services */ "./apps/generator-cli/src/app/services/index.ts");
var _a, _b, _c, _d;






let VersionManagerController = class VersionManagerController {
    constructor(logger, program, ui, service) {
        this.logger = logger;
        this.program = program;
        this.ui = ui;
        this.service = service;
        this.mainCommand = this.program
            .command('version-manager')
            .description('Manage used / installed generator version');
        this.listCommand = this.mainCommand
            .command('list [versionTags...]')
            .description('lists all published versions')
            .option('-j, --json', 'print as json', false)
            .action(tags => this.list(tags));
        this.setCommand = this.mainCommand
            .command('set <versionTags...>')
            .description('set version to use')
            .action(tags => this.set(tags));
        this.list = (versionTags) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const versions = yield this.service.search(versionTags).toPromise();
            if (this.listCommand.opts().json) {
                this.logger.log(JSON.stringify(versions, null, 2));
                return;
            }
            if (versions.length < 1) {
                this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_4__["red"]('No results for: ' + versionTags.join(' ')));
                return;
            }
            const { version, installed } = yield this.table(versions);
            const isSelected = yield this.service.isSelectedVersion(version);
            const choice = (name, cb = () => null, color = v => v) => ({ name: color(name), value: cb });
            const choices = [choice('exit')];
            if (!installed) {
                choices.unshift(choice('download', () => this.service.download(version), chalk__WEBPACK_IMPORTED_MODULE_4__["yellow"]));
            }
            else if (!isSelected) {
                choices.unshift(choice('remove', () => this.service.remove(version), chalk__WEBPACK_IMPORTED_MODULE_4__["red"]));
            }
            if (!isSelected) {
                choices.unshift(choice('use', () => this.service.setSelectedVersion(version), chalk__WEBPACK_IMPORTED_MODULE_4__["green"]));
            }
            yield (yield this.ui.list({ name: 'next', message: 'Whats next?', choices }))();
        });
        this.set = (versionTags) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const versions = yield this.service.search(versionTags).toPromise();
            if (versions.length > 0) {
                yield this.service.setSelectedVersion(versions[0].version);
                return;
            }
            this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_4__["red"](`Unable to find version matching criteria "${versionTags.join(' ')}"`));
        });
        this.table = (versions) => this.ui.table({
            printColNum: false,
            message: 'The following releases are available:',
            name: 'version',
            rows: versions.map(version => {
                const stable = version.versionTags.includes('stable');
                const selected = this.service.isSelectedVersion(version.version);
                const versionTags = version.versionTags.map(t => t === 'latest' ? chalk__WEBPACK_IMPORTED_MODULE_4__["green"](t) : t);
                return {
                    value: version,
                    short: version.version,
                    row: {
                        '☐': selected ? '☒' : '☐',
                        releasedAt: version.releaseDate.toISOString().split('T')[0],
                        version: stable ? chalk__WEBPACK_IMPORTED_MODULE_4__["yellow"](version.version) : chalk__WEBPACK_IMPORTED_MODULE_4__["gray"](version.version),
                        installed: version.installed ? chalk__WEBPACK_IMPORTED_MODULE_4__["green"]('yes') : chalk__WEBPACK_IMPORTED_MODULE_4__["red"]('no'),
                        versionTags: versionTags.join(' '),
                    },
                };
            }),
        });
    }
};
VersionManagerController = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Controller"])(),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_constants__WEBPACK_IMPORTED_MODULE_2__["LOGGER"])),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_constants__WEBPACK_IMPORTED_MODULE_2__["COMMANDER_PROGRAM"])),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [typeof (_a = typeof _constants__WEBPACK_IMPORTED_MODULE_2__["LOGGER"] !== "undefined" && _constants__WEBPACK_IMPORTED_MODULE_2__["LOGGER"]) === "function" ? _a : Object, typeof (_b = typeof commander__WEBPACK_IMPORTED_MODULE_3__["Command"] !== "undefined" && commander__WEBPACK_IMPORTED_MODULE_3__["Command"]) === "function" ? _b : Object, typeof (_c = typeof _services__WEBPACK_IMPORTED_MODULE_5__["UIService"] !== "undefined" && _services__WEBPACK_IMPORTED_MODULE_5__["UIService"]) === "function" ? _c : Object, typeof (_d = typeof _services__WEBPACK_IMPORTED_MODULE_5__["VersionManagerService"] !== "undefined" && _services__WEBPACK_IMPORTED_MODULE_5__["VersionManagerService"]) === "function" ? _d : Object])
], VersionManagerController);



/***/ }),

/***/ "./apps/generator-cli/src/app/services/config.service.ts":
/*!***************************************************************!*\
  !*** ./apps/generator-cli/src/app/services/config.service.ts ***!
  \***************************************************************/
/*! exports provided: ConfigService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ConfigService", function() { return ConfigService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "tslib");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @nestjs/common */ "@nestjs/common");
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../constants */ "./apps/generator-cli/src/app/constants/index.ts");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var fs_extra__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! fs-extra */ "fs-extra");
/* harmony import */ var fs_extra__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(fs_extra__WEBPACK_IMPORTED_MODULE_5__);
var _a;






let ConfigService = class ConfigService {
    constructor(logger) {
        this.logger = logger;
        this.cwd = process.env.PWD || process.env.INIT_CWD || process.cwd();
        this.configFile = path__WEBPACK_IMPORTED_MODULE_2__["resolve"](this.cwd, 'openapitools.json');
        this.defaultConfig = {
            $schema: './node_modules/@openapitools/openapi-generator-cli/config.schema.json',
            spaces: 2,
            'generator-cli': {
                version: undefined,
            },
        };
    }
    get useDocker() {
        return this.get('generator-cli.useDocker', false);
    }
    get dockerImageName() {
        return this.get('generator-cli.dockerImageName', 'openapitools/openapi-generator-cli');
    }
    get(path, defaultValue) {
        return Object(lodash__WEBPACK_IMPORTED_MODULE_4__["get"])(this.read(), path, defaultValue);
    }
    has(path) {
        return Object(lodash__WEBPACK_IMPORTED_MODULE_4__["has"])(this.read(), path);
    }
    set(path, value) {
        this.write(Object(lodash__WEBPACK_IMPORTED_MODULE_4__["set"])(this.read(), path, value));
        return this;
    }
    read() {
        fs_extra__WEBPACK_IMPORTED_MODULE_5__["ensureFileSync"](this.configFile);
        return Object(lodash__WEBPACK_IMPORTED_MODULE_4__["merge"])(this.defaultConfig, fs_extra__WEBPACK_IMPORTED_MODULE_5__["readJSONSync"](this.configFile, { throws: false, encoding: 'utf8' }));
    }
    write(config) {
        fs_extra__WEBPACK_IMPORTED_MODULE_5__["writeJSONSync"](this.configFile, config, { encoding: 'utf8', spaces: config.spaces || 2 });
    }
};
ConfigService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_constants__WEBPACK_IMPORTED_MODULE_3__["LOGGER"])),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [typeof (_a = typeof _constants__WEBPACK_IMPORTED_MODULE_3__["LOGGER"] !== "undefined" && _constants__WEBPACK_IMPORTED_MODULE_3__["LOGGER"]) === "function" ? _a : Object])
], ConfigService);



/***/ }),

/***/ "./apps/generator-cli/src/app/services/generator.service.ts":
/*!******************************************************************!*\
  !*** ./apps/generator-cli/src/app/services/generator.service.ts ***!
  \******************************************************************/
/*! exports provided: GeneratorService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GeneratorService", function() { return GeneratorService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "tslib");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @nestjs/common */ "@nestjs/common");
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var concurrently__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! concurrently */ "concurrently");
/* harmony import */ var concurrently__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(concurrently__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var fs_extra__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! fs-extra */ "fs-extra");
/* harmony import */ var fs_extra__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(fs_extra__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var glob__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! glob */ "glob");
/* harmony import */ var glob__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(glob__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! chalk */ "chalk");
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(chalk__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _version_manager_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./version-manager.service */ "./apps/generator-cli/src/app/services/version-manager.service.ts");
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./config.service */ "./apps/generator-cli/src/app/services/config.service.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../constants */ "./apps/generator-cli/src/app/constants/index.ts");
var _a, _b, _c;











let GeneratorService = class GeneratorService {
    constructor(logger, configService, versionManager) {
        this.logger = logger;
        this.configService = configService;
        this.versionManager = versionManager;
        this.configPath = 'generator-cli.generators';
        this.enabled = this.configService.has(this.configPath);
        this.cmd = (customGenerator, appendix, dockerVolumes = {}) => {
            if (this.configService.useDocker) {
                const volumes = Object.entries(dockerVolumes).map(([k, v]) => `-v "${v}:${k}"`).join(' ');
                return [
                    `docker run --rm`,
                    volumes,
                    this.versionManager.getDockerImageName(),
                    'generate',
                    appendix
                ].join(' ');
            }
            const cliPath = this.versionManager.filePath();
            const subCmd = customGenerator
                ? `-cp "${[cliPath, customGenerator].join(this.isWin() ? ';' : ':')}" org.openapitools.codegen.OpenAPIGenerator`
                : `-jar "${cliPath}"`;
            return [
                'java',
                process.env['JAVA_OPTS'],
                subCmd,
                'generate',
                appendix,
            ].filter(lodash__WEBPACK_IMPORTED_MODULE_2__["isString"]).join(' ');
        };
        this.isWin = () => process.platform === "win32";
    }
    generate(customGenerator, ...keys) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const cwd = this.configService.cwd;
            const generators = Object.entries(this.configService.get(this.configPath, {}));
            const enabledGenerators = generators
                .filter(([key, { disabled }]) => {
                if (!disabled)
                    return true;
                this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["grey"](`[info] Skip ${chalk__WEBPACK_IMPORTED_MODULE_7__["yellow"](key)}, because this generator is disabled`));
                return false;
            })
                .filter(([key]) => {
                if (!keys.length || keys.includes(key))
                    return true;
                this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["grey"](`[info] Skip ${chalk__WEBPACK_IMPORTED_MODULE_7__["yellow"](key)}, because only ${keys.map((k) => chalk__WEBPACK_IMPORTED_MODULE_7__["yellow"](k)).join(', ')} shall run`));
                return false;
            });
            const globsWithNoMatches = [];
            const commands = Object(lodash__WEBPACK_IMPORTED_MODULE_2__["flatten"])(enabledGenerators.map(([name, config]) => {
                // eslint-disable-next-line @typescript-eslint/no-unused-vars
                const { glob: globPattern, disabled } = config, params = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__rest"])(config, ["glob", "disabled"]);
                if (!globPattern) {
                    return [{
                            name: `[${name}] ${params.inputSpec}`,
                            command: this.buildCommand(cwd, params, customGenerator)
                        }];
                }
                const specFiles = glob__WEBPACK_IMPORTED_MODULE_6__["sync"](globPattern, { cwd });
                if (specFiles.length < 1) {
                    globsWithNoMatches.push(globPattern);
                }
                return glob__WEBPACK_IMPORTED_MODULE_6__["sync"](globPattern, { cwd }).map(spec => ({
                    name: `[${name}] ${spec}`,
                    command: this.buildCommand(cwd, params, customGenerator, spec)
                }));
            }));
            const generated = commands.length > 0 && (yield (() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                try {
                    this.printResult(yield concurrently__WEBPACK_IMPORTED_MODULE_3__(commands, { maxProcesses: 10 }));
                    return true;
                }
                catch (e) {
                    this.printResult(e);
                    return false;
                }
            }))());
            globsWithNoMatches.map(g => this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["yellow"](`[warn] Did not found any file matching glob "${g}"`)));
            return generated;
        });
    }
    printResult(res) {
        this.logger.log(Object(lodash__WEBPACK_IMPORTED_MODULE_2__["sortBy"])(res, 'command.name').map(({ exitCode, command }) => {
            const failed = exitCode > 0;
            return [
                chalk__WEBPACK_IMPORTED_MODULE_7__[failed ? 'red' : 'green'](command.name),
                ...(failed ? [chalk__WEBPACK_IMPORTED_MODULE_7__["yellow"](`  ${command.command}\n`)] : []),
            ].join('\n');
        }).join('\n'));
    }
    buildCommand(cwd, params, customGenerator, specFile) {
        const dockerVolumes = {};
        const absoluteSpecPath = specFile ? path__WEBPACK_IMPORTED_MODULE_4__["resolve"](cwd, specFile) : String(params.inputSpec);
        const ext = path__WEBPACK_IMPORTED_MODULE_4__["extname"](absoluteSpecPath);
        const name = path__WEBPACK_IMPORTED_MODULE_4__["basename"](absoluteSpecPath, ext);
        const placeholders = {
            name,
            Name: Object(lodash__WEBPACK_IMPORTED_MODULE_2__["upperFirst"])(name),
            cwd,
            base: path__WEBPACK_IMPORTED_MODULE_4__["basename"](absoluteSpecPath),
            dir: specFile && path__WEBPACK_IMPORTED_MODULE_4__["dirname"](absoluteSpecPath),
            path: absoluteSpecPath,
            relDir: specFile && path__WEBPACK_IMPORTED_MODULE_4__["dirname"](specFile),
            relPath: specFile,
            ext: ext.split('.').slice(-1).pop()
        };
        const command = Object.entries(Object.assign({ inputSpec: absoluteSpecPath }, params)).map(([k, v]) => {
            const key = Object(lodash__WEBPACK_IMPORTED_MODULE_2__["kebabCase"])(k);
            const value = (() => {
                switch (typeof v) {
                    case 'object':
                        return `"${Object.entries(v).map(z => z.join('=')).join(',')}"`;
                    case 'number':
                    case 'bigint':
                        return `${v}`;
                    case 'boolean':
                        return undefined;
                    default:
                        if (this.configService.useDocker) {
                            v = this.replacePlaceholders(placeholders, v);
                            if (key === 'output') {
                                fs_extra__WEBPACK_IMPORTED_MODULE_5__["ensureDirSync"](v);
                            }
                            if (fs_extra__WEBPACK_IMPORTED_MODULE_5__["existsSync"](v)) {
                                dockerVolumes[`/local/${key}`] = path__WEBPACK_IMPORTED_MODULE_4__["resolve"](cwd, v);
                                return `"/local/${key}"`;
                            }
                        }
                        return `"${v}"`;
                }
            })();
            return value === undefined ? `--${key}` : `--${key}=${value}`;
        }).join(' ');
        return this.cmd(customGenerator, this.replacePlaceholders(placeholders, command), dockerVolumes);
    }
    replacePlaceholders(placeholders, input) {
        return Object.entries(placeholders)
            .filter(([, replacement]) => !!replacement)
            .reduce((acc, [search, replacement]) => {
            return acc.split(`#{${search}}`).join(replacement);
        }, input);
    }
};
GeneratorService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_constants__WEBPACK_IMPORTED_MODULE_10__["LOGGER"])),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [typeof (_a = typeof _constants__WEBPACK_IMPORTED_MODULE_10__["LOGGER"] !== "undefined" && _constants__WEBPACK_IMPORTED_MODULE_10__["LOGGER"]) === "function" ? _a : Object, typeof (_b = typeof _config_service__WEBPACK_IMPORTED_MODULE_9__["ConfigService"] !== "undefined" && _config_service__WEBPACK_IMPORTED_MODULE_9__["ConfigService"]) === "function" ? _b : Object, typeof (_c = typeof _version_manager_service__WEBPACK_IMPORTED_MODULE_8__["VersionManagerService"] !== "undefined" && _version_manager_service__WEBPACK_IMPORTED_MODULE_8__["VersionManagerService"]) === "function" ? _c : Object])
], GeneratorService);



/***/ }),

/***/ "./apps/generator-cli/src/app/services/index.ts":
/*!******************************************************!*\
  !*** ./apps/generator-cli/src/app/services/index.ts ***!
  \******************************************************/
/*! exports provided: UIService, ConfigService, GeneratorService, PassThroughService, VersionManagerService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _ui_service__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ui.service */ "./apps/generator-cli/src/app/services/ui.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "UIService", function() { return _ui_service__WEBPACK_IMPORTED_MODULE_0__["UIService"]; });

/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./config.service */ "./apps/generator-cli/src/app/services/config.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ConfigService", function() { return _config_service__WEBPACK_IMPORTED_MODULE_1__["ConfigService"]; });

/* harmony import */ var _generator_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./generator.service */ "./apps/generator-cli/src/app/services/generator.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "GeneratorService", function() { return _generator_service__WEBPACK_IMPORTED_MODULE_2__["GeneratorService"]; });

/* harmony import */ var _pass_through_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pass-through.service */ "./apps/generator-cli/src/app/services/pass-through.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "PassThroughService", function() { return _pass_through_service__WEBPACK_IMPORTED_MODULE_3__["PassThroughService"]; });

/* harmony import */ var _version_manager_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./version-manager.service */ "./apps/generator-cli/src/app/services/version-manager.service.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "VersionManagerService", function() { return _version_manager_service__WEBPACK_IMPORTED_MODULE_4__["VersionManagerService"]; });








/***/ }),

/***/ "./apps/generator-cli/src/app/services/pass-through.service.ts":
/*!*********************************************************************!*\
  !*** ./apps/generator-cli/src/app/services/pass-through.service.ts ***!
  \*********************************************************************/
/*! exports provided: PassThroughService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PassThroughService", function() { return PassThroughService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "tslib");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @nestjs/common */ "@nestjs/common");
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! chalk */ "chalk");
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(chalk__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! child_process */ "child_process");
/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(child_process__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var commander__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! commander */ "commander");
/* harmony import */ var commander__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(commander__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../constants */ "./apps/generator-cli/src/app/constants/index.ts");
/* harmony import */ var _generator_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./generator.service */ "./apps/generator-cli/src/app/services/generator.service.ts");
/* harmony import */ var _version_manager_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./version-manager.service */ "./apps/generator-cli/src/app/services/version-manager.service.ts");
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./config.service */ "./apps/generator-cli/src/app/services/config.service.ts");
var _a, _b, _c, _d, _e;










let PassThroughService = class PassThroughService {
    constructor(logger, program, versionManager, configService, generatorService) {
        this.logger = logger;
        this.program = program;
        this.versionManager = versionManager;
        this.configService = configService;
        this.generatorService = generatorService;
        this.passThrough = (cmd) => {
            const args = [cmd.name(), ...cmd.args];
            Object(child_process__WEBPACK_IMPORTED_MODULE_3__["spawn"])(this.cmd(), args, {
                stdio: 'inherit',
                shell: true
            }).on('exit', process.exit);
        };
        this.getCommands = () => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const [help, completion] = (yield Promise.all([
                this.run('help'),
                this.run('completion').catch(() => '')
            ]));
            const commands = help.split('\n')
                .filter(line => Object(lodash__WEBPACK_IMPORTED_MODULE_5__["startsWith"])(line, ' '))
                .map(lodash__WEBPACK_IMPORTED_MODULE_5__["trim"])
                .map(line => line.match(/^([a-z-]+)\s+(.+)/i).slice(1))
                .reduce((acc, [cmd, desc]) => (Object.assign(Object.assign({}, acc), { [cmd]: desc })), {});
            const allCommands = completion.split('\n')
                .map(lodash__WEBPACK_IMPORTED_MODULE_5__["trim"])
                .filter(c => c.length > 0 && c.indexOf('--') !== 0);
            for (const cmd of allCommands) {
                commands[cmd] = commands[cmd] || '';
            }
            return Object.entries(commands);
        });
        this.run = (subCmd) => new Promise((resolve, reject) => {
            Object(child_process__WEBPACK_IMPORTED_MODULE_3__["exec"])(`${this.cmd()} ${subCmd}`, (error, stdout, stderr) => {
                error ? reject(new Error(stderr)) : resolve(stdout);
            });
        });
        this.isWin = () => process.platform === "win32";
    }
    init() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.program
                .allowUnknownOption()
                .option("--custom-generator <generator>", "Custom generator jar");
            const commands = (yield this.getCommands()).reduce((acc, [name, desc]) => {
                return acc.set(name, this.program
                    .command(name, { hidden: !desc })
                    .description(desc)
                    .allowUnknownOption()
                    .action((_, c) => this.passThrough(c)));
            }, new Map());
            /*
            * Overwrite help command
            */
            commands.get('help').action((_, cmd) => {
                if (!cmd.args.length) {
                    this.printHelp(this.program);
                    return;
                }
                const [helpCmd] = cmd.args;
                if (commands.has(helpCmd)) {
                    this.printHelp(commands.get(helpCmd));
                }
                this.passThrough(cmd);
            });
            /*
             * Overwrite generate command
             */
            commands.get('generate')
                .option("--generator-key <generator...>", "Run generator by key. Separate by comma to run many generators")
                .action((_, cmd) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                var _a;
                if (cmd.args.length === 0 || cmd.opts().generatorKey) {
                    const customGenerator = (_a = this.program.opts()) === null || _a === void 0 ? void 0 : _a.customGenerator;
                    const generatorKeys = cmd.opts().generatorKey || [];
                    if (this.generatorService.enabled) {
                        // @todo cover by unit test
                        if (!(yield this.generatorService.generate(customGenerator, ...generatorKeys))) {
                            this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_2__["red"]('Code generation failed'));
                            process.exit(1);
                        }
                        return;
                    }
                }
                this.passThrough(cmd);
            }));
        });
    }
    cmd() {
        var _a;
        if (this.configService.useDocker) {
            return [
                `docker run --rm -v "${this.configService.cwd}:/local"`,
                this.versionManager.getDockerImageName(),
            ].join(' ');
        }
        const customGenerator = (_a = this.program.opts()) === null || _a === void 0 ? void 0 : _a.customGenerator;
        const cliPath = this.versionManager.filePath();
        const subCmd = customGenerator
            ? `-cp "${[cliPath, customGenerator].join(this.isWin() ? ';' : ':')}" org.openapitools.codegen.OpenAPIGenerator`
            : `-jar "${cliPath}"`;
        return ['java', process.env['JAVA_OPTS'], subCmd].filter(lodash__WEBPACK_IMPORTED_MODULE_5__["isString"]).join(' ');
    }
    printHelp(cmd) {
        console.log(chalk__WEBPACK_IMPORTED_MODULE_2__["cyanBright"](cmd.helpInformation()));
    }
};
PassThroughService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_constants__WEBPACK_IMPORTED_MODULE_6__["LOGGER"])),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(1, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_constants__WEBPACK_IMPORTED_MODULE_6__["COMMANDER_PROGRAM"])),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [typeof (_a = typeof _constants__WEBPACK_IMPORTED_MODULE_6__["LOGGER"] !== "undefined" && _constants__WEBPACK_IMPORTED_MODULE_6__["LOGGER"]) === "function" ? _a : Object, typeof (_b = typeof commander__WEBPACK_IMPORTED_MODULE_4__["Command"] !== "undefined" && commander__WEBPACK_IMPORTED_MODULE_4__["Command"]) === "function" ? _b : Object, typeof (_c = typeof _version_manager_service__WEBPACK_IMPORTED_MODULE_8__["VersionManagerService"] !== "undefined" && _version_manager_service__WEBPACK_IMPORTED_MODULE_8__["VersionManagerService"]) === "function" ? _c : Object, typeof (_d = typeof _config_service__WEBPACK_IMPORTED_MODULE_9__["ConfigService"] !== "undefined" && _config_service__WEBPACK_IMPORTED_MODULE_9__["ConfigService"]) === "function" ? _d : Object, typeof (_e = typeof _generator_service__WEBPACK_IMPORTED_MODULE_7__["GeneratorService"] !== "undefined" && _generator_service__WEBPACK_IMPORTED_MODULE_7__["GeneratorService"]) === "function" ? _e : Object])
], PassThroughService);



/***/ }),

/***/ "./apps/generator-cli/src/app/services/ui.service.ts":
/*!***********************************************************!*\
  !*** ./apps/generator-cli/src/app/services/ui.service.ts ***!
  \***********************************************************/
/*! exports provided: UIService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UIService", function() { return UIService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "tslib");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @nestjs/common */ "@nestjs/common");
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var inquirer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! inquirer */ "inquirer");
/* harmony import */ var inquirer__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(inquirer__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var console_table__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! console.table */ "console.table");
/* harmony import */ var console_table__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(console_table__WEBPACK_IMPORTED_MODULE_3__);

// import ora from 'ora'



let UIService = class UIService {
    table(config) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const table = Object(console_table__WEBPACK_IMPORTED_MODULE_3__["getTable"])(config.rows.map(({ row }, index) => {
                return config.printColNum === false ? row : (Object.assign({ '#': index + 1 }, row));
            }));
            const [header, separator, ...rows] = table.trim().split('\n');
            return this.list({
                name: config.name,
                message: config.message,
                choices: [
                    new inquirer__WEBPACK_IMPORTED_MODULE_2__["Separator"](header),
                    new inquirer__WEBPACK_IMPORTED_MODULE_2__["Separator"](separator),
                    ...rows.map((name, index) => ({
                        name,
                        short: config.rows[index].short,
                        value: config.rows[index].value,
                    })),
                    new inquirer__WEBPACK_IMPORTED_MODULE_2__["Separator"](separator),
                    new inquirer__WEBPACK_IMPORTED_MODULE_2__["Separator"](' '.repeat(separator.length)),
                ],
            });
        });
    }
    list(config) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const separatorCount = config
                .choices
                .filter((c) => c instanceof inquirer__WEBPACK_IMPORTED_MODULE_2__["Separator"])
                .length;
            const res = yield Object(inquirer__WEBPACK_IMPORTED_MODULE_2__["prompt"])([{
                    type: 'list',
                    name: config.name,
                    pageSize: process.stdout.rows - separatorCount - 1,
                    message: config.message,
                    choices: config.choices,
                }]);
            return res[config.name];
        });
    }
};
UIService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()
], UIService);



/***/ }),

/***/ "./apps/generator-cli/src/app/services/version-manager.service.ts":
/*!************************************************************************!*\
  !*** ./apps/generator-cli/src/app/services/version-manager.service.ts ***!
  \************************************************************************/
/*! exports provided: VersionManagerService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "VersionManagerService", function() { return VersionManagerService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "tslib");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @nestjs/common */ "@nestjs/common");
/* harmony import */ var _nestjs_common__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "rxjs/operators");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash */ "lodash");
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var fs_extra__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! fs-extra */ "fs-extra");
/* harmony import */ var fs_extra__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(fs_extra__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! path */ "path");
/* harmony import */ var path__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(path__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! os */ "os");
/* harmony import */ var os__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(os__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! chalk */ "chalk");
/* harmony import */ var chalk__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(chalk__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var compare_versions__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! compare-versions */ "compare-versions");
/* harmony import */ var compare_versions__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(compare_versions__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../constants */ "./apps/generator-cli/src/app/constants/index.ts");
/* harmony import */ var _config_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./config.service */ "./apps/generator-cli/src/app/services/config.service.ts");
/* harmony import */ var _config_schema_json__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../config.schema.json */ "./apps/generator-cli/src/config.schema.json");
var _config_schema_json__WEBPACK_IMPORTED_MODULE_11___namespace = /*#__PURE__*/__webpack_require__.t(/*! ../../config.schema.json */ "./apps/generator-cli/src/config.schema.json", 1);
/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! child_process */ "child_process");
/* harmony import */ var child_process__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(child_process__WEBPACK_IMPORTED_MODULE_12__);
var _a, _b, _c;













const mvn = {
    repo: 'https://search.maven.org',
    groupId: 'org.openapitools',
    artifactId: 'openapi-generator-cli'
};
let VersionManagerService = class VersionManagerService {
    constructor(logger, httpService, configService) {
        this.logger = logger;
        this.httpService = httpService;
        this.configService = configService;
        this.customStorageDir = this.configService.get('generator-cli.storageDir');
        this.storage = this.customStorageDir ? path__WEBPACK_IMPORTED_MODULE_5__["resolve"](this.configService.cwd, this.customStorageDir.replace('~', os__WEBPACK_IMPORTED_MODULE_6__["homedir"]())) : path__WEBPACK_IMPORTED_MODULE_5__["resolve"](__dirname, './versions');
    }
    getAll() {
        const queryUrl = this.replacePlaceholders(this.configService.get('generator-cli.repository.queryUrl') ||
            _config_schema_json__WEBPACK_IMPORTED_MODULE_11__["properties"]['generator-cli'].properties.repository.queryUrl.default);
        return this.httpService.get(queryUrl).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(({ data }) => data.response.docs), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(docs => docs.map((doc) => {
            var _a;
            return ({
                version: doc.v,
                versionTags: [
                    ...(((_a = doc.v.match(/^[0-9]+\.[0-9]+\.[0-9]+$/)) === null || _a === void 0 ? void 0 : _a.concat('stable')) || []),
                    ...(doc.v.match(/(^[0-9]+\.[0-9]+\.[0-9]+)-(([a-z]+)[0-9]?)$/) || [])
                ],
                releaseDate: new Date(doc.timestamp),
                installed: this.isDownloaded(doc.v),
                downloadLink: this.createDownloadLink(doc.v)
            });
        })), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(versions => {
            const latestVersion = this.filterVersionsByTags(versions, ['stable'])
                .sort((l, r) => compare_versions__WEBPACK_IMPORTED_MODULE_8__(l.version, r.version)).pop();
            latestVersion.versionTags.push('latest'); // works, because it's a reference
            return versions;
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])((e) => {
            this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["red"](`Unable to query repository, because of: "${e.message}"`));
            this.printResponseError(e);
            return [];
        }));
    }
    search(tags) {
        return this.getAll().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(versions => this.filterVersionsByTags(versions, tags)));
    }
    isSelectedVersion(versionName) {
        return versionName === this.getSelectedVersion();
    }
    getSelectedVersion() {
        return this.configService.get('generator-cli.version');
    }
    getDockerImageName(versionName) {
        return `${this.configService.dockerImageName}:v${versionName || this.getSelectedVersion()}`;
    }
    setSelectedVersion(versionName) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const downloaded = yield this.downloadIfNeeded(versionName);
            if (downloaded) {
                this.configService.set('generator-cli.version', versionName);
                this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["green"](`Did set selected version to ${versionName}`));
            }
        });
    }
    remove(versionName) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            if (this.configService.useDocker) {
                yield new Promise(resolve => {
                    Object(child_process__WEBPACK_IMPORTED_MODULE_12__["spawn"])('docker', ['rmi', this.getDockerImageName(versionName)], {
                        stdio: 'inherit',
                        shell: true
                    }).on('exit', () => resolve());
                });
            }
            else {
                fs_extra__WEBPACK_IMPORTED_MODULE_4__["removeSync"](this.filePath(versionName));
            }
            this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["green"](`Removed ${versionName}`));
        });
    }
    download(versionName) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["yellow"](`Download ${versionName} ...`));
            if (this.configService.useDocker) {
                yield new Promise(resolve => {
                    Object(child_process__WEBPACK_IMPORTED_MODULE_12__["spawn"])('docker', ['pull', this.getDockerImageName(versionName)], {
                        stdio: 'inherit',
                        shell: true
                    }).on('exit', () => resolve());
                });
                this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["green"](`Downloaded ${versionName}`));
                return;
            }
            const downloadLink = this.createDownloadLink(versionName);
            const filePath = this.filePath(versionName);
            try {
                yield this.httpService
                    .get(downloadLink, { responseType: 'stream' })
                    .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["switchMap"])(res => new Promise(resolve => {
                    fs_extra__WEBPACK_IMPORTED_MODULE_4__["ensureDirSync"](this.storage);
                    const temporaryDirectory = fs_extra__WEBPACK_IMPORTED_MODULE_4__["mkdtempSync"](path__WEBPACK_IMPORTED_MODULE_5__["join"](os__WEBPACK_IMPORTED_MODULE_6__["tmpdir"](), 'generator-cli-'));
                    const temporaryFilePath = path__WEBPACK_IMPORTED_MODULE_5__["join"](temporaryDirectory, versionName);
                    const file = fs_extra__WEBPACK_IMPORTED_MODULE_4__["createWriteStream"](temporaryFilePath);
                    res.data.pipe(file);
                    file.on('finish', content => {
                        fs_extra__WEBPACK_IMPORTED_MODULE_4__["moveSync"](temporaryFilePath, filePath, { overwrite: true });
                        resolve(content);
                    });
                }))).toPromise();
                if (this.customStorageDir) {
                    this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["green"](`Downloaded ${versionName} to custom storage location ${this.storage}`));
                }
                else {
                    this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["green"](`Downloaded ${versionName}`));
                }
                return true;
            }
            catch (e) {
                this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["red"](`Download failed, because of: "${e.message}"`));
                this.printResponseError(e);
                return false;
            }
        });
    }
    downloadIfNeeded(versionName) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return this.isDownloaded(versionName) || this.download(versionName);
        });
    }
    isDownloaded(versionName) {
        if (this.configService.useDocker) {
            const { status } = Object(child_process__WEBPACK_IMPORTED_MODULE_12__["spawnSync"])('docker', ['image', 'inspect', this.getDockerImageName(versionName)]);
            return status === 0;
        }
        return fs_extra__WEBPACK_IMPORTED_MODULE_4__["existsSync"](path__WEBPACK_IMPORTED_MODULE_5__["resolve"](this.storage, `${versionName}.jar`));
    }
    filterVersionsByTags(versions, tags) {
        if (tags.length < 1) {
            return versions;
        }
        return versions.filter(v => tags.every(tag => {
            return v.versionTags.some(vTag => vTag.indexOf(tag) === 0);
        }));
    }
    createDownloadLink(versionName) {
        return this.replacePlaceholders((this.configService.get('generator-cli.repository.downloadUrl') ||
            _config_schema_json__WEBPACK_IMPORTED_MODULE_11__["properties"]['generator-cli'].properties.repository.downloadUrl.default), { versionName });
    }
    replacePlaceholders(str, additionalPlaceholders = {}) {
        const placeholders = Object.assign(Object.assign({}, additionalPlaceholders), { groupId: Object(lodash__WEBPACK_IMPORTED_MODULE_3__["replace"])(mvn.groupId, '.', '/'), artifactId: Object(lodash__WEBPACK_IMPORTED_MODULE_3__["replace"])(mvn.artifactId, '.', '/'), 'group.id': mvn.groupId, 'artifact.id': mvn.artifactId });
        for (const [k, v] of Object.entries(placeholders)) {
            str = str.split(`$\{${k}}`).join(v);
        }
        return str;
    }
    printResponseError(error) {
        if (error.isAxiosError) {
            this.logger.log(chalk__WEBPACK_IMPORTED_MODULE_7__["red"]('\nResponse:'));
            Object.entries(error.response.headers).forEach(a => this.logger.log(...a));
            this.logger.log();
            error.response.data.on('data', data => this.logger.log(data.toString('utf8')));
        }
    }
    filePath(versionName = this.getSelectedVersion()) {
        return path__WEBPACK_IMPORTED_MODULE_5__["resolve"](this.storage, `${versionName}.jar`);
    }
};
VersionManagerService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Injectable"])(),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__param"])(0, Object(_nestjs_common__WEBPACK_IMPORTED_MODULE_1__["Inject"])(_constants__WEBPACK_IMPORTED_MODULE_9__["LOGGER"])),
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"])("design:paramtypes", [typeof (_a = typeof _constants__WEBPACK_IMPORTED_MODULE_9__["LOGGER"] !== "undefined" && _constants__WEBPACK_IMPORTED_MODULE_9__["LOGGER"]) === "function" ? _a : Object, typeof (_b = typeof _nestjs_common__WEBPACK_IMPORTED_MODULE_1__["HttpService"] !== "undefined" && _nestjs_common__WEBPACK_IMPORTED_MODULE_1__["HttpService"]) === "function" ? _b : Object, typeof (_c = typeof _config_service__WEBPACK_IMPORTED_MODULE_10__["ConfigService"] !== "undefined" && _config_service__WEBPACK_IMPORTED_MODULE_10__["ConfigService"]) === "function" ? _c : Object])
], VersionManagerService);



/***/ }),

/***/ "./apps/generator-cli/src/config.schema.json":
/*!***************************************************!*\
  !*** ./apps/generator-cli/src/config.schema.json ***!
  \***************************************************/
/*! exports provided: $id, $schema, title, type, required, additionalProperties, properties, definitions, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"$id\":\"https://openapitools.org/openapi-generator-cli/config.schema.json\",\"$schema\":\"http://json-schema.org/draft-07/schema#\",\"title\":\"OpenAPI Generator CLI - Config\",\"type\":\"object\",\"required\":[\"generator-cli\"],\"additionalProperties\":false,\"properties\":{\"$schema\":{\"type\":\"string\"},\"spaces\":{\"type\":\"number\",\"default\":2},\"generator-cli\":{\"type\":\"object\",\"required\":[\"version\"],\"properties\":{\"version\":{\"type\":\"string\"},\"storageDir\":{\"type\":\"string\"},\"repository\":{\"queryUrl\":{\"type\":\"string\",\"default\":\"https://search.maven.org/solrsearch/select?q=g:${group.id}+AND+a:${artifact.id}&core=gav&start=0&rows=200\"},\"downloadUrl\":{\"type\":\"string\",\"default\":\"https://repo1.maven.org/maven2/${groupId}/${artifactId}/${versionName}/${artifactId}-${versionName}.jar\"}},\"useDocker\":{\"type\":\"boolean\",\"default\":false},\"dockerImageName\":{\"type\":\"string\",\"default\":\"openapitools/openapi-generator-cli\"},\"generators\":{\"type\":\"object\",\"additionalProperties\":{\"$ref\":\"#/definitions/generator\"}}}}},\"definitions\":{\"strOrAnyObject\":{\"anyOf\":[{\"type\":\"string\"},{\"type\":\"object\",\"additionalProperties\":true}]},\"generator\":{\"type\":\"object\",\"anyOf\":[{\"required\":[\"inputSpec\",\"output\",\"generatorName\"]},{\"required\":[\"glob\",\"output\",\"generatorName\"]}],\"properties\":{\"glob\":{\"description\":\"matches local specification files using a glob pattern\",\"type\":\"string\",\"minLength\":1},\"output\":{\"type\":\"string\",\"minLength\":1},\"disabled\":{\"type\":\"boolean\",\"default\":false},\"generatorName\":{\"description\":\"generator to use (see list command for list)\",\"anyOf\":[{\"type\":\"string\"},{\"type\":\"string\",\"enum\":[\"ada\",\"ada-server\",\"android\",\"apache2\",\"apex\",\"asciidoc\",\"aspnetcore\",\"avro-schema\",\"bash\",\"c\",\"clojure\",\"cpp-pistache-server\",\"cpp-qt5-client\",\"cpp-qt5-qhttpengine-server\",\"cpp-restbed-server\",\"cpp-restsdk\",\"cpp-tizen\",\"csharp\",\"csharp-nancyfx\",\"csharp-netcore\",\"cwiki\",\"dart\",\"dart-dio\",\"dart-jaguar\",\"dynamic-html\",\"eiffel\",\"elixir\",\"elm\",\"erlang-client\",\"erlang-proper\",\"erlang-server\",\"flash\",\"fsharp-functions\",\"fsharp-giraffe-server\",\"go\",\"go-experimental\",\"go-gin-server\",\"go-server\",\"graphql-nodejs-express-server\",\"graphql-schema\",\"groovy\",\"haskell\",\"haskell-http-client\",\"html\",\"html2\",\"java\",\"java-inflector\",\"java-msf4j\",\"java-pkmst\",\"java-play-framework\",\"java-undertow-server\",\"java-vertx\",\"java-vertx-web\",\"javascript\",\"javascript-apollo\",\"javascript-closure-angular\",\"javascript-flowtyped\",\"jaxrs-cxf\",\"jaxrs-cxf-cdi\",\"jaxrs-cxf-client\",\"jaxrs-cxf-extended\",\"jaxrs-jersey\",\"jaxrs-resteasy\",\"jaxrs-resteasy-eap\",\"jaxrs-spec\",\"jmeter\",\"k6\",\"kotlin\",\"kotlin-server\",\"kotlin-spring\",\"kotlin-vertx\",\"lua\",\"markdown\",\"mysql-schema\",\"nim\",\"nodejs-express-server\",\"objc\",\"ocaml\",\"openapi\",\"openapi-yaml\",\"perl\",\"php\",\"php-laravel\",\"php-lumen\",\"php-silex\",\"php-slim4\",\"php-symfony\",\"php-ze-ph\",\"powershell\",\"powershell-experimental\",\"protobuf-schema\",\"python\",\"python-aiohttp\",\"python-blueplanet\",\"python-experimental\",\"python-flask\",\"r\",\"ruby\",\"ruby-on-rails\",\"ruby-sinatra\",\"rust\",\"rust-server\",\"scala-akka\",\"scala-akka-http-server\",\"scala-finch\",\"scala-gatling\",\"scala-lagom-server\",\"scala-play-server\",\"scala-sttp\",\"scalatra\",\"scalaz\",\"spring\",\"swift4\",\"swift5\",\"typescript-angular\",\"typescript-angularjs\",\"typescript-aurelia\",\"typescript-axios\",\"typescript-fetch\",\"typescript-inversify\",\"typescript-jquery\",\"typescript-node\",\"typescript-redux-query\",\"typescript-rxjs\"]}]},\"auth\":{\"type\":\"string\",\"description\":\"adds authorization headers when fetching the OpenAPI definitions remotely. Pass in a URL-encoded string of name:header with a comma separating multiple values\"},\"apiNameSuffix\":{\"type\":\"string\",\"description\":\"suffix that will be appended to all API names ('tags'). Default: Api. e.g. Pet => PetApi. Note: Only ruby, python, jaxrs generators support this feature at the moment\"},\"apiPackage\":{\"type\":\"string\",\"description\":\"package for generated api classes\"},\"artifactId\":{\"type\":\"string\",\"description\":\"artifactId in generated pom.xml. This also becomes part of the generated library's filename\"},\"artifactVersion\":{\"type\":\"string\",\"description\":\"artifact version in generated pom.xml. This also becomes part of the generated library's filename\"},\"config\":{\"type\":\"string\",\"description\":\"path to configuration file. It can be JSON or YAML\"},\"dryRun\":{\"type\":\"boolean\",\"description\":\"try things out and report on potential changes (without actually making changes)\"},\"engine\":{\"type\":\"string\",\"enum\":[\"mustache\",\"handlebars\"],\"description\":\"templating engine: \\\"mustache\\\" (default) or \\\"handlebars\\\" (beta)\"},\"enablePostProcessFile\":{\"type\":\"boolean\",\"description\":\"enable post-processing file using environment variables\"},\"generateAliasAsModel\":{\"type\":\"boolean\",\"description\":\"generate model implementation for aliases to map and array schemas. An 'alias' is an array, map, or list which is defined inline in a OpenAPI document and becomes a model in the generated code. A 'map' schema is an object that can have undeclared properties, i.e. the 'additionalproperties' attribute is set on that object. An 'array' schema is a list of sub schemas in a OAS document\"},\"gitHost\":{\"type\":\"string\",\"description\":\"git host, e.g. gitlab.com\"},\"gitRepoId\":{\"type\":\"string\",\"description\":\"git repo ID, e.g. openapi-generator\"},\"gitUserId\":{\"type\":\"string\",\"description\":\"git user ID, e.g. openapitools\"},\"globalProperty\":{\"anyOf\":[{\"type\":\"string\"},{\"type\":\"object\",\"additionalProperties\":true}],\"description\":\"sets specified global properties (previously called 'system properties') in the format of name=value,name=value (or multiple options, each with name=value)\"},\"groupId\":{\"type\":\"string\",\"description\":\"groupId in generated pom.xml\"},\"httpUserAgent\":{\"type\":\"string\",\"description\":\"HTTP user agent, e.g. codegen_csharp_api_client, default to 'OpenAPI-Generator/{packageVersion}}/{language}'\"},\"inputSpec\":{\"type\":\"string\",\"description\":\"location of the OpenAPI spec, as URL or file (required if not loaded via config using -c)\"},\"ignoreFileOverride\":{\"type\":\"string\",\"description\":\"specifies an override location for the .openapi-generator-ignore file. Most useful on initial generation.\\n\"},\"importMappings\":{\"anyOf\":[{\"type\":\"string\"},{\"type\":\"object\",\"additionalProperties\":true}],\"description\":\"specifies mappings between a given class and the import that should be used for that class in the format of type=import,type=import. You can also have multiple occurrences of this option\"},\"instantiationTypes\":{\"anyOf\":[{\"type\":\"string\"},{\"type\":\"object\",\"additionalProperties\":true}],\"description\":\"sets instantiation type mappings in the format of type=instantiatedType,type=instantiatedType.For example (in Java): array=ArrayList,map=HashMap. In other words array types will get instantiated as ArrayList in generated code. You can also have multiple occurrences of this option\"},\"invokerPackage\":{\"type\":\"string\",\"description\":\"root package for generated code\"},\"languageSpecificPrimitives\":{\"anyOf\":[{\"type\":\"string\"},{\"type\":\"object\",\"additionalProperties\":true}],\"description\":\"specifies additional language specific primitive types in the format of type1,type2,type3,type3. For example: String,boolean,Boolean,Double. You can also have multiple occurrences of this option\"},\"legacyDiscriminatorBehavior\":{\"type\":\"boolean\",\"description\":\"this flag is used by OpenAPITools codegen to influence the processing of the discriminator attribute in OpenAPI documents. This flag has no impact if the OAS document does not use the discriminator attribute. The default value of this flag is set in each language-specific code generator (e.g. Python, Java, go...)using the method toModelName. Note to developers supporting a language generator in OpenAPITools; to fully support the discriminator attribute as defined in the OAS specification 3.x, language generators should set this flag to true by default; however this requires updating the mustache templates to generate a language-specific discriminator lookup function that iterates over {{#mappedModels}} and does not iterate over {{children}}, {{#anyOf}}, or {{#oneOf}}\"},\"library\":{\"type\":\"string\",\"description\":\"library template (sub-template)\"},\"logToStderr\":{\"type\":\"boolean\",\"description\":\"write all log messages (not just errors) to STDOUT. Useful for piping the JSON output of debug options (e.g. `-DdebugOperations`) to an external parser directly while testing a generator\"},\"minimalUpdate\":{\"type\":\"boolean\",\"description\":\"only write output files that have changed\"},\"modelNamePrefix\":{\"type\":\"string\",\"description\":\"prefix that will be prepended to all model names\"},\"modelNameSuffix\":{\"type\":\"string\",\"description\":\"suffix that will be appended to all model names\"},\"modelPackage\":{\"type\":\"string\",\"description\":\"package for generated models\"},\"additionalProperties\":{\"description\":\"sets additional properties that can be referenced by the mustache templates in the format of name=value,name=value. You can also have multiple occurrences of this option\",\"anyOf\":[{\"type\":\"string\"},{\"type\":\"object\",\"additionalProperties\":true}]},\"packageName\":{\"type\":\"string\",\"description\":\"package for generated classes (where supported)\"},\"releaseNote\":{\"type\":\"string\",\"description\":\"release note, default to 'Minor update'\"},\"removeOperationIdPrefix\":{\"type\":\"boolean\",\"description\":\"remove prefix of operationId, e.g. config_getId => getId\"},\"reservedWordsMappings\":{\"anyOf\":[{\"type\":\"string\"},{\"type\":\"object\",\"additionalProperties\":true}],\"description\":\"specifies how a reserved name should be escaped to. Otherwise, the default _<name> is used. For example id=identifier. You can also have multiple occurrences of this option\"},\"skipOverwrite\":{\"type\":\"boolean\",\"description\":\"specifies if the existing files should be overwritten during the generation\"},\"serverVariables\":{\"anyOf\":[{\"type\":\"string\"},{\"type\":\"object\",\"additionalProperties\":true}],\"description\":\"sets server variables overrides for spec documents which support variable templating of servers\"},\"skipValidateSpec\":{\"type\":\"boolean\",\"description\":\"skips the default behavior of validating an input specification\"},\"strictSpec\":{\"type\":\"boolean\",\"description\":\"'MUST' and 'SHALL' wording in OpenAPI spec is strictly adhered to. e.g. when false, no fixes will be applied to documents which pass validation but don't follow the spec\"},\"templateDir\":{\"type\":\"string\",\"description\":\"folder containing the template files\"},\"typeMappings\":{\"anyOf\":[{\"type\":\"string\"},{\"type\":\"object\",\"additionalProperties\":true}],\"description\":\"sets mappings between OpenAPI spec types and generated code types in the format of OpenAPIType=generatedType,OpenAPIType=generatedType. For example: array=List,map=Map,string=String. You can also have multiple occurrences of this option\"},\"verbose\":{\"type\":\"boolean\",\"description\":\"verbose mode\"}}}}}");

/***/ }),

/***/ "./apps/generator-cli/src/main.ts":
/*!****************************************!*\
  !*** ./apps/generator-cli/src/main.ts ***!
  \****************************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "tslib");
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(tslib__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _nestjs_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @nestjs/core */ "@nestjs/core");
/* harmony import */ var _nestjs_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_nestjs_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./apps/generator-cli/src/app/app.module.ts");
/**
 * This is not a production server yet!
 * This is only a minimal backend to get started.
 */



function bootstrap() {
    return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
        yield _nestjs_core__WEBPACK_IMPORTED_MODULE_1__["NestFactory"].createApplicationContext(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"], { logger: false });
    });
}
bootstrap();


/***/ }),

/***/ 0:
/*!**********************************************!*\
  !*** multi ./apps/generator-cli/src/main.ts ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! /home/runner/work/openapi-generator-cli/openapi-generator-cli/apps/generator-cli/src/main.ts */"./apps/generator-cli/src/main.ts");


/***/ }),

/***/ "@nestjs/common":
/*!*********************************!*\
  !*** external "@nestjs/common" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@nestjs/common");

/***/ }),

/***/ "@nestjs/core":
/*!*******************************!*\
  !*** external "@nestjs/core" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@nestjs/core");

/***/ }),

/***/ "chalk":
/*!************************!*\
  !*** external "chalk" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("chalk");

/***/ }),

/***/ "child_process":
/*!********************************!*\
  !*** external "child_process" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("child_process");

/***/ }),

/***/ "commander":
/*!****************************!*\
  !*** external "commander" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("commander");

/***/ }),

/***/ "compare-versions":
/*!***********************************!*\
  !*** external "compare-versions" ***!
  \***********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("compare-versions");

/***/ }),

/***/ "concurrently":
/*!*******************************!*\
  !*** external "concurrently" ***!
  \*******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("concurrently");

/***/ }),

/***/ "console.table":
/*!********************************!*\
  !*** external "console.table" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("console.table");

/***/ }),

/***/ "fs-extra":
/*!***************************!*\
  !*** external "fs-extra" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("fs-extra");

/***/ }),

/***/ "glob":
/*!***********************!*\
  !*** external "glob" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("glob");

/***/ }),

/***/ "inquirer":
/*!***************************!*\
  !*** external "inquirer" ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("inquirer");

/***/ }),

/***/ "lodash":
/*!*************************!*\
  !*** external "lodash" ***!
  \*************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("lodash");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),

/***/ "rxjs/operators":
/*!*********************************!*\
  !*** external "rxjs/operators" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("rxjs/operators");

/***/ }),

/***/ "tslib":
/*!************************!*\
  !*** external "tslib" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("tslib");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("url");

/***/ })

/******/ })));
//# sourceMappingURL=main.js.map